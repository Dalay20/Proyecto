/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ec.edu.espol.proyecto;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;


/**
 *
 * @author naomi
 */
public class Proyecto {

    public static void main(String[] args) throws IOException, NoSuchAlgorithmException {
        Menu.iniciarMenu();
  
    }    
}


